#include <EEPROM.h>
#define BAUD_RATE 2400

void setup() {
 
  Serial.begin(BAUD_RATE);
}

void loop() {
  
  if (Serial.available() > 0) {
   
    while (Serial.available() > 0) {
      char data = Serial.read();
      int addr = EEPROM.read(0); 
      EEPROM.write(addr, data);
      addr++;
      EEPROM.write(0, addr); 
    }
  }
  
  // Check if all data is received and start transmitting back to PC
  int addr = EEPROM.read(0);
  if (addr >= 1000) {
    for (int i = 0; i < 1000; i++) {
      char data = EEPROM.read(i + 1);
      Serial.write(data); 
    }
    
    EEPROM.write(0, 0);
  }
}
